# Asset Caching

The documentation for this topic has been moved to the following articles in [Microsoft Learn](https://learn.microsoft.com/vcpkg):

* [Asset caching](https://learn.microsoft.com/vcpkg/users/assetcaching)
